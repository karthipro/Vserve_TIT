<?php



	$usernamee ="sairam"; 
	$passwordd ="123456"; 
	$numbers="8190083902";
	$message="HAi";
                $xml_data ="<SmsQueue><Account><User>$usernamee</User><Password>$passwordd</Password><SenderId>VSTCBE</SenderId><Channel>trans</Channel><DCS>0</DCS><FlashSms>0</FlashSms><Route>4</Route></Account><Messages><Message><Number>$numbers</Number><Text>$message</Text></Message></Messages></SmsQueue>";
$URL = "http://sms.vstcbe.com/api/mt/SendSMS?data=";

			$ch = curl_init($URL);
			curl_setopt($ch, CURLOPT_MUTE, true);
			curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: text/xml'));
			curl_setopt($ch, CURLOPT_POSTFIELDS, "$xml_data");
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			$output = curl_exec($ch);
			curl_close($ch); 
			

			   echo "<script> alert(' to $mobno !');</script>";
			   
			   
	


?>
	 